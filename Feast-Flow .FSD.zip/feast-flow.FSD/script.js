/* =====================================================
   FeastFlow – EventEats Exchange
   Vanilla JS: pricing engine, menu builder, vendor
   comparison, tasting booking, escrow simulator, PDF quote
   ===================================================== */
'use strict';

/* ---------- Helpers ---------- */
const $  = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
const fmt = n => '₹' + Math.round(n).toLocaleString('en-IN');
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const clamp = (n, a, b) => Math.min(b, Math.max(a, n));
const localISO = d => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const pretty = iso => iso ? new Date(iso + 'T00:00:00').toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }) : 'To be decided';
const stars = r => '★'.repeat(Math.round(r)) + '☆'.repeat(5 - Math.round(r));

/* ---------- Pricing constants ---------- */
const SERVICE_RATE = 0.05;   // staff service fee
const GST_RATE     = 0.05;   // GST on catering
const JAIN_FEE     = 20;     // extra per Jain plate for segregated kitchen
const MIN_G = 50, MAX_G = 500;
const volumePct = g => (g >= 200 ? 0.10 : g >= 100 ? 0.05 : 0);

/* ---------- Data: courses ---------- */
const COURSES = [
  { id: 'starters', label: 'Starters',      icon: '🥟' },
  { id: 'mains',    label: 'Main Course',   icon: '🍛' },
  { id: 'breads',   label: 'Breads & Rice', icon: '🫓' },
  { id: 'desserts', label: 'Desserts',      icon: '🍨' },
  { id: 'counters', label: 'Live Counters', icon: '🔥' }
];

/* ---------- Data: dishes (rate = ₹ per plate, baseline) ---------- */
const DISHES = [
  // Starters
  { id: 's1', course: 'starters', name: 'Paneer Tikka',            rate: 70,  diet: 'veg',    emoji: '🧀', desc: 'Char-grilled cottage cheese with mint chutney' },
  { id: 's2', course: 'starters', name: 'Veg Spring Rolls',        rate: 45,  diet: 'veg',    emoji: '🥟', desc: 'Crispy rolls with sweet-chilli dip' },
  { id: 's3', course: 'starters', name: 'Hara Bhara Kebab',        rate: 50,  diet: 'veg',    emoji: '🥬', desc: 'Spinach & green pea patties' },
  { id: 's4', course: 'starters', name: 'Crispy Corn',             rate: 40,  diet: 'jain',   emoji: '🌽', desc: 'Golden fried corn tossed in spices (no onion/garlic)' },
  { id: 's5', course: 'starters', name: 'Chicken Tikka',           rate: 85,  diet: 'nonveg', emoji: '🍗', desc: 'Tandoor-roasted marinated chicken' },
  { id: 's6', course: 'starters', name: 'Crispy Fish Fingers',     rate: 95,  diet: 'nonveg', emoji: '🐟', desc: 'Crumb-fried fish with tartare sauce' },
  { id: 's7', course: 'starters', name: 'Cheese Garlic Bruschetta', rate: 55, diet: 'veg',    emoji: '🍞', desc: 'Continental toasted bread with tomato & cheese' },
  { id: 's8', course: 'starters', name: 'Dahi Ke Kebab',           rate: 60,  diet: 'veg',    emoji: '🥣', desc: 'Melt-in-mouth hung curd kebabs' },
  // Mains
  { id: 'm1', course: 'mains', name: 'Paneer Butter Masala',       rate: 95,  diet: 'veg',    emoji: '🍛', desc: 'Creamy tomato gravy with soft paneer' },
  { id: 'm2', course: 'mains', name: 'Dal Makhani',                rate: 70,  diet: 'veg',    emoji: '🫘', desc: 'Slow-cooked black lentils, buttery & rich' },
  { id: 'm3', course: 'mains', name: 'Hyderabadi Veg Biryani',     rate: 85,  diet: 'veg',    emoji: '🍚', desc: 'Dum-cooked basmati with garden vegetables' },
  { id: 'm4', course: 'mains', name: 'Chicken Dum Biryani',        rate: 120, diet: 'nonveg', emoji: '🍗', desc: 'Signature layered biryani with raita' },
  { id: 'm5', course: 'mains', name: 'Butter Chicken',             rate: 125, diet: 'nonveg', emoji: '🍖', desc: 'Tender chicken in velvety tomato-butter sauce' },
  { id: 'm6', course: 'mains', name: 'Jain Mix Veg Curry',         rate: 65,  diet: 'jain',   emoji: '🥕', desc: 'Seasonal vegetables, no root veg / onion / garlic' },
  { id: 'm7', course: 'mains', name: 'Jain Dal Tadka',             rate: 55,  diet: 'jain',   emoji: '🍲', desc: 'Yellow dal tempered with hing & jeera' },
  { id: 'm8', course: 'mains', name: 'Creamy Alfredo Pasta',       rate: 100, diet: 'veg',    emoji: '🍝', desc: 'Penne in white garlic-cream sauce' },
  { id: 'm9', course: 'mains', name: 'Baked Veg Lasagna',          rate: 110, diet: 'veg',    emoji: '🧆', desc: 'Layered pasta baked with cheese & vegetables' },
  { id: 'm10', course: 'mains', name: 'Mutton Rogan Josh',         rate: 175, diet: 'nonveg', emoji: '🥘', desc: 'Kashmiri-style slow-braised mutton' },
  // Breads & Rice
  { id: 'b1', course: 'breads', name: 'Butter Naan',               rate: 20,  diet: 'veg',    emoji: '🫓', desc: 'Soft tandoor-baked flatbread' },
  { id: 'b2', course: 'breads', name: 'Tandoori Roti',             rate: 12,  diet: 'jain',   emoji: '🫓', desc: 'Whole-wheat roti from the tandoor' },
  { id: 'b3', course: 'breads', name: 'Garlic Naan',               rate: 25,  diet: 'veg',    emoji: '🧄', desc: 'Naan topped with garlic & coriander' },
  { id: 'b4', course: 'breads', name: 'Steamed Jeera Rice',        rate: 30,  diet: 'jain',   emoji: '🍚', desc: 'Fragrant basmati with cumin' },
  { id: 'b5', course: 'breads', name: 'Cheesy Garlic Bread',       rate: 28,  diet: 'veg',    emoji: '🥖', desc: 'Continental toasted loaf, herb butter' },
  // Desserts
  { id: 'd1', course: 'desserts', name: 'Gulab Jamun',             rate: 30,  diet: 'veg',    emoji: '🟤', desc: 'Warm khoya dumplings in rose syrup' },
  { id: 'd2', course: 'desserts', name: 'Rasmalai',                rate: 35,  diet: 'veg',    emoji: '🍮', desc: 'Soft paneer discs in saffron milk' },
  { id: 'd3', course: 'desserts', name: 'Ice Cream Scoops',        rate: 35,  diet: 'veg',    emoji: '🍨', desc: 'Vanilla, strawberry & butterscotch' },
  { id: 'd4', course: 'desserts', name: 'Fruit Custard',           rate: 35,  diet: 'jain',   emoji: '🍓', desc: 'Chilled custard with seasonal fruit' },
  { id: 'd5', course: 'desserts', name: 'Brownie with Hot Fudge',  rate: 50,  diet: 'veg',    emoji: '🍫', desc: 'Warm walnut brownie, chocolate sauce' },
  { id: 'd6', course: 'desserts', name: 'Tiramisu Cups',           rate: 65,  diet: 'veg',    emoji: '🍰', desc: 'Classic Italian coffee dessert (eggless)' },
  // Live counters (rate per plate + one-time equipment fee)
  { id: 'c1', course: 'counters', name: 'Chaat Counter',           rate: 45,  diet: 'veg',    emoji: '🥗', desc: 'Pani puri, bhel & dahi papdi made live', equip: 4000 },
  { id: 'c2', course: 'counters', name: 'Pasta Station',           rate: 70,  diet: 'veg',    emoji: '🍝', desc: 'Choose sauce, pasta & toppings – tossed live', equip: 5000 },
  { id: 'c3', course: 'counters', name: 'Ice Cream Teppanyaki',    rate: 80,  diet: 'jain',   emoji: '🧊', desc: 'Rolled ice cream on a freezing steel plate', equip: 8000 },
  { id: 'c4', course: 'counters', name: 'Live Dosa Counter',       rate: 55,  diet: 'veg',    emoji: '🥞', desc: 'Crisp dosas with 3 chutneys & sambar', equip: 4500 },
  { id: 'c5', course: 'counters', name: 'Live Tandoor Grill',      rate: 90,  diet: 'veg',    emoji: '🔥', desc: 'Veg kebabs & tikkas fresh off the grill', equip: 7000 }
];
const DISH = Object.fromEntries(DISHES.map(d => [d.id, d]));

/* ---------- Data: event types ---------- */
const EVENTS = {
  college:   { label: 'College Fest',  icon: '🎓', buffer: 0.10, guests: 150, hint: 'Student events see high walk-in attendance – a 10% buffer prevents running short. Budget-friendly chaat & biryani combos work best.',
               pkg: ['s2', 's4', 'm3', 'm2', 'b1', 'd3', 'c1'] },
  birthday:  { label: 'Birthday',      icon: '🎂', buffer: 0.08, guests: 60,  hint: 'Kids and family parties favour pasta, finger foods and ice cream. Plan 8% buffer for surprise plus-ones.',
               pkg: ['s2', 's7', 'm8', 'm1', 'b5', 'd5', 'd3', 'c2'] },
  corporate: { label: 'Corporate',     icon: '💼', buffer: 0.05, guests: 120, hint: 'Corporate lunches have predictable RSVPs – only a 5% buffer needed. Keep it elegant and quick to serve.',
               pkg: ['s1', 's5', 'm1', 'm4', 'b1', 'b4', 'd6', 'd2'] },
  wedding:   { label: 'Wedding',       icon: '💍', buffer: 0.12, guests: 300, hint: 'Weddings attract uninvited guests and repeat servings – a 12% buffer is the industry norm. Add live counters for the wow factor.',
               pkg: ['s1', 's8', 's5', 'm1', 'm2', 'm4', 'b1', 'b3', 'b4', 'd1', 'd2', 'c5', 'c3'] }
};

/* ---------- Data: vendors ---------- */
const VENDORS = [
  { id: 'royal', name: 'Royal Feast Caterers', emoji: '👑', color: 'linear-gradient(135deg,#7a1f2b,#b4361f)', tagline: 'Premium weddings & corporate banquets',
    rating: 4.8, reviews: 312, mult: 1.0, min: 50, max: 1000, tariff: [450, 900], hygiene: 9.6, area: 'Banjara Hills', exp: '18 yrs',
    events: ['wedding', 'corporate', 'birthday', 'college'], diets: ['veg', 'nonveg', 'jain'], excludes: [],
    testimonials: [['Ananya R.', 'Flawless service for our 400-guest wedding. Food was piping hot and the live counters were a hit.', 5], ['Dept. of CSE', 'Professional staff, spotless buffet and generous portions for our banquet.', 5]] },
  { id: 'spice', name: 'Spice Symphony', emoji: '🌶️', color: 'linear-gradient(135deg,#c2410c,#f59e0b)', tagline: 'Authentic Hyderabadi flavours at fair prices',
    rating: 4.5, reviews: 214, mult: 0.93, min: 30, max: 600, tariff: [350, 700], hygiene: 9.1, area: 'Madhapur', exp: '11 yrs',
    events: ['birthday', 'college', 'corporate', 'wedding'], diets: ['veg', 'nonveg', 'jain'], excludes: ['c3'],
    testimonials: [['Rahul M.', 'Their biryani is unreal. Delivered on time for 120 guests and the price was very reasonable.', 5], ['Priya S.', 'Good variety and polite staff. Dessert could have been a bit warmer.', 4]] },
  { id: 'campus', name: 'Campus Bites Co.', emoji: '🎒', color: 'linear-gradient(135deg,#0f766e,#14b8a6)', tagline: 'Budget menus built for student clubs',
    rating: 4.3, reviews: 158, mult: 0.75, min: 25, max: 400, tariff: [250, 500], hygiene: 8.7, area: 'Kukatpally', exp: '6 yrs',
    events: ['college', 'birthday'], diets: ['veg', 'nonveg'], excludes: ['s6', 'm9', 'm10', 'd6', 'c2', 'c3'],
    testimonials: [['Tech Club Lead', 'Best prices for fests and they were flexible with our budget. Portions were solid.', 4], ['Sneha K.', 'Arrived early, clean setup. Limited continental options but great for the price.', 4]] },
  { id: 'green', name: 'Green Leaf Pure Veg', emoji: '🌿', color: 'linear-gradient(135deg,#166534,#4ade80)', tagline: 'Pure-veg & dedicated Jain kitchen',
    rating: 4.6, reviews: 187, mult: 0.9, min: 40, max: 500, tariff: [320, 650], hygiene: 9.8, area: 'Secunderabad', exp: '14 yrs',
    events: ['wedding', 'corporate', 'birthday', 'college'], diets: ['veg', 'jain'], excludes: ['s5', 's6', 'm4', 'm5', 'm10'],
    testimonials: [['Mrs. Jain', 'Strictly Jain preparation with separate utensils. We could eat without any worry.', 5], ['Kiran T.', 'Spotless kitchen, beautiful presentation. Highly recommended for veg events.', 5]] },
  { id: 'grand', name: 'The Grand Continental', emoji: '🥂', color: 'linear-gradient(135deg,#1e3a8a,#6366f1)', tagline: 'Fine-dining continental & global buffets',
    rating: 4.7, reviews: 96, mult: 1.2, min: 100, max: 800, tariff: [600, 900], hygiene: 9.4, area: 'Gachibowli', exp: '9 yrs',
    events: ['wedding', 'corporate'], diets: ['veg', 'nonveg'], excludes: ['c1', 'c4'],
    testimonials: [['Vikram A.', 'Elegant plating and impeccable service for our annual dinner.', 5], ['TechNova HR', 'Premium experience. A bit pricier but worth it for client events.', 4]] }
];
const VENDOR = Object.fromEntries(VENDORS.map(v => [v.id, v]));

/* ---------- Data: gallery ---------- */
const GALLERY = [
  { e: 'college',   t: 'Farewell Night 2025',      v: 'royal',  g: 180, bg: 'linear-gradient(135deg,#f59e0b,#ea580c)', ic: '🎓', q: 'The chaat counter had a queue all night – nobody left hungry and we stayed under budget!', by: 'Rohit, Event Head' },
  { e: 'wedding',   t: 'Sangeet & Reception',      v: 'royal',  g: 420, bg: 'linear-gradient(135deg,#be185d,#f472b6)', ic: '💍', q: 'Our guests are still talking about the Teppanyaki ice cream. Flawless execution.', by: 'Meera & Arjun' },
  { e: 'birthday',  t: '10th Birthday Bash',       v: 'spice',  g: 55,  bg: 'linear-gradient(135deg,#0ea5e9,#6366f1)', ic: '🎂', q: 'Kids loved the pasta station. Parents loved the transparent bill.', by: 'Sunitha, Parent' },
  { e: 'corporate', t: 'Annual Team Lunch',        v: 'grand',  g: 130, bg: 'linear-gradient(135deg,#334155,#64748b)', ic: '💼', q: 'Elegant, punctual and perfectly portioned. Zero wastage thanks to the buffer estimate.', by: 'Neha, HR Manager' },
  { e: 'college',   t: 'Tech Fest Food Court',     v: 'campus', g: 250, bg: 'linear-gradient(135deg,#14b8a6,#22c55e)', ic: '🍕', q: 'Campus Bites matched our tiny budget and still delivered great food.', by: 'Tech Club' },
  { e: 'wedding',   t: 'Pure-Veg Jain Wedding',    v: 'green',  g: 200, bg: 'linear-gradient(135deg,#16a34a,#a3e635)', ic: '🌿', q: 'Strict Jain kitchen, separate utensils – our elders were truly comfortable.', by: 'The Shah Family' }
];

/* ---------- State ---------- */
const KEY = 'feastflow.v2';
const state = {
  eventType: 'college', eventName: '', eventDate: '',
  guests: 100, nonveg: 0, jain: 0,
  selected: [], vendorId: 'royal', buffer: false,
  compare: ['royal', 'spice'], escrow: 0
};
let tastings = [];
let ui = { tab: 'starters', filter: 'all', query: '', vendorEvent: 'all', vendorSort: 'rating', gallery: 'all' };

function save() {
  try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { /* storage unavailable */ }
}
function load() {
  try {
    const s = JSON.parse(localStorage.getItem(KEY) || 'null');
    if (s && typeof s === 'object') Object.assign(state, s);
    const t = JSON.parse(localStorage.getItem('feastflow.tastings') || '[]');
    if (Array.isArray(t)) tastings = t;
  } catch (e) { /* ignore corrupt data */ }
  state.guests = clamp(parseInt(state.guests) || 100, MIN_G, MAX_G);
  state.selected = (state.selected || []).filter(id => DISH[id]);
  if (!VENDOR[state.vendorId]) state.vendorId = 'royal';
  state.compare = (state.compare || []).filter(id => VENDOR[id]).slice(0, 3);
  if (!EVENTS[state.eventType]) state.eventType = 'college';
  fixDiet();
}
function fixDiet() {
  state.nonveg = clamp(parseInt(state.nonveg) || 0, 0, state.guests);
  state.jain = clamp(parseInt(state.jain) || 0, 0, state.guests - state.nonveg);
}
const vegCount = () => state.guests - state.nonveg - state.jain;

/* =====================================================
   PRICING ENGINE
   TotalQuote = Σ segment guests × (Σ eligible item rates × vendor
   multiplier × VolumeDiscount) + buffer + equipment + service + GST
   ===================================================== */
const eligible = (dish, seg) => seg === 'nonveg' ? true : seg === 'veg' ? dish.diet !== 'nonveg' : dish.diet === 'jain';

function calc(vendor, st = state) {
  const items = st.selected.map(id => DISH[id]).filter(Boolean);
  const offered = items.filter(d => !vendor.excludes.includes(d.id));
  const missing = items.filter(d => vendor.excludes.includes(d.id));
  const counts = { veg: st.guests - st.nonveg - st.jain, nonveg: st.nonveg, jain: st.jain };

  const billed = Math.max(st.guests, vendor.min);
  const f = st.guests ? billed / st.guests : 1;            // scale factor if below vendor minimum
  const vp = volumePct(billed);
  const unitMult = vendor.mult * (1 - vp);

  const segs = {};
  let rawBase = 0;
  ['veg', 'nonveg', 'jain'].forEach(s => {
    const rate = offered.filter(d => eligible(d, s)).reduce((a, d) => a + d.rate, 0);
    segs[s] = { count: counts[s], baseRate: rate, plate: rate * unitMult };
    rawBase += rate * counts[s];
  });

  const gross = rawBase * f * vendor.mult;                 // before discount
  const discount = gross * vp;
  const food = gross - discount;
  const bufferPct = st.buffer ? EVENTS[st.eventType].buffer : 0;
  const bufferAmt = food * bufferPct;
  const jainFee = vendor.diets.includes('jain') ? counts.jain * JAIN_FEE * f : 0;
  const equipment = offered.reduce((a, d) => a + (d.equip || 0), 0);
  const foodTotal = food + bufferAmt + jainFee;
  const service = foodTotal * SERVICE_RATE;
  const taxable = foodTotal + service + equipment;
  const gst = taxable * GST_RATE;
  const grand = taxable + gst;

  // itemized lines (for quotation)
  const lines = offered.map(d => {
    const qty = ['veg', 'nonveg', 'jain'].reduce((a, s) => a + (eligible(d, s) ? counts[s] : 0), 0) * f;
    const unit = d.rate * unitMult;
    return { dish: d, qty, unit, amount: unit * qty };
  });

  return {
    vendor, items, offered, missing, segs, billed, vp, gross, discount, food, bufferPct, bufferAmt,
    jainFee, equipment, foodTotal, service, gst, grand, lines,
    perPlate: st.guests ? grand / st.guests : 0,
    shortfall: billed > st.guests,
    dietIssues: [
      counts.nonveg > 0 && !vendor.diets.includes('nonveg') ? 'No non-veg kitchen' : null,
      counts.jain > 0 && !vendor.diets.includes('jain') ? 'No Jain kitchen' : null
    ].filter(Boolean)
  };
}

/* =====================================================
   TOAST + MODAL HELPERS
   ===================================================== */
let toastTimer;
function toast(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 3000);
}
function openModal(id) { $(id).hidden = false; document.body.style.overflow = 'hidden'; }
function closeModals() { $$('.modal').forEach(m => (m.hidden = true)); document.body.style.overflow = ''; }

/* Animated numbers */
function animateNum(el, to, fmtFn = fmt) {
  const from = el._v || 0;
  el._v = to;
  if (from === to || window.matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = fmtFn(to); return; }
  const start = performance.now(), dur = 450;
  const step = now => {
    const p = clamp((now - start) / dur, 0, 1);
    const e = 1 - Math.pow(1 - p, 3);
    el.textContent = fmtFn(from + (to - from) * e);
    if (p < 1 && el._v === to) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

/* =====================================================
   RENDER: EVENT PROFILER
   ===================================================== */
function renderEventChips() {
  $('#eventChips').innerHTML = Object.entries(EVENTS).map(([k, e]) =>
    `<button type="button" class="chip ${state.eventType === k ? 'active' : ''}" data-ev="${k}" role="radio" aria-checked="${state.eventType === k}">${e.icon} ${e.label}</button>`).join('');
  const e = EVENTS[state.eventType];
  $('#eventHint').textContent = `💡 ${e.hint}`;
}

function syncGuestInputs() {
  const pct = ((state.guests - MIN_G) / (MAX_G - MIN_G)) * 100;
  const sl = $('#guestSlider');
  sl.value = state.guests;
  sl.style.setProperty('--pct', pct + '%');
  $('#guestNumber').value = state.guests;
  $('#vegCount').value = vegCount();
  $('#nonvegCount').value = state.nonveg;
  $('#jainCount').value = state.jain;
  $('#nonvegCount').max = state.guests;
  $('#jainCount').max = state.guests;
  const vp = volumePct(state.guests);
  $$('.tier').forEach((t, i) => t.classList.toggle('on', (i === 0 && vp === 0) || (i === 1 && vp === .05) || (i === 2 && vp === .1)));
  const g = state.guests || 1;
  const bar = $('#dietBar');
  $('.v', bar).style.width = (vegCount() / g * 100) + '%';
  $('.n', bar).style.width = (state.nonveg / g * 100) + '%';
  $('.j', bar).style.width = (state.jain / g * 100) + '%';
}

/* =====================================================
   RENDER: MENU BUILDER
   ===================================================== */
function renderTabs() {
  $('#courseTabs').innerHTML = COURSES.map(c => {
    const n = state.selected.filter(id => DISH[id].course === c.id).length;
    return `<button type="button" class="tab ${ui.tab === c.id ? 'active' : ''}" data-tab="${c.id}" role="tab" aria-selected="${ui.tab === c.id}">${c.icon} ${c.label}<span class="count">${n}</span></button>`;
  }).join('');
}

function renderDishes() {
  const v = VENDOR[state.vendorId];
  const q = ui.query.trim().toLowerCase();
  const popular = EVENTS[state.eventType].pkg;
  let list = DISHES.filter(d => d.course === ui.tab);
  if (ui.filter === 'veg') list = list.filter(d => d.diet !== 'nonveg');
  if (ui.filter === 'nonveg') list = list.filter(d => d.diet === 'nonveg');
  if (ui.filter === 'jain') list = list.filter(d => d.diet === 'jain');
  if (q) list = list.filter(d => (d.name + ' ' + d.desc).toLowerCase().includes(q));

  $('#dishGrid').innerHTML = list.length ? list.map(d => {
    const sel = state.selected.includes(d.id);
    const na = v.excludes.includes(d.id);
    const price = Math.round(d.rate * v.mult);
    const dietLabel = d.diet === 'nonveg' ? 'Non-veg' : d.diet === 'jain' ? 'Jain-safe' : 'Veg';
    return `<button type="button" class="dish ${sel ? 'sel' : ''} ${na ? 'na' : ''}" data-dish="${d.id}" aria-pressed="${sel}">
      ${na ? `<span class="badge bad">Not offered by ${esc(v.name.split(' ')[0])}</span>` : popular.includes(d.id) ? '<span class="badge">⭐ Popular</span>' : ''}
      <div class="dish-top"><span class="dish-emoji">${d.emoji}</span><span class="diet-tag ${d.diet}" title="${dietLabel}"></span></div>
      <h5>${d.name}</h5>
      <p>${d.desc}</p>
      ${d.equip ? `<span class="equip">+ ${fmt(d.equip)} equipment fee (one-time)</span>` : ''}
      <div class="dish-foot"><span class="price">${fmt(price)} <small>/ plate</small></span><span class="check">✓</span></div>
    </button>`;
  }).join('') : '<div class="empty">No dishes match your filter. Try another course or clear the search.</div>';
}

function toggleDish(id) {
  const i = state.selected.indexOf(id);
  if (i >= 0) state.selected.splice(i, 1); else state.selected.push(id);
  update();
}

function applyPackage() {
  const pkg = EVENTS[state.eventType].pkg.filter(id => state.nonveg > 0 || DISH[id].diet !== 'nonveg');
  state.selected = [...pkg];
  update();
  toast(`✨ Applied the recommended ${EVENTS[state.eventType].label} package`);
}

/* =====================================================
   RENDER: SUMMARY
   ===================================================== */
function renderSummary() {
  const v = VENDOR[state.vendorId];
  const c = calc(v);

  $('#vendorSelect').innerHTML = VENDORS.map(x => `<option value="${x.id}" ${x.id === v.id ? 'selected' : ''}>${x.emoji} ${x.name} – ${x.rating}★</option>`).join('');
  $('#vendorMini').innerHTML = `<span>⭐ ${v.rating} (${v.reviews})</span><span>👥 Min ${v.min} guests</span><span>🧼 Hygiene ${v.hygiene}/10</span>`;

  animateNum($('#perPlate'), c.perPlate);
  animateNum($('#grandTotal'), c.grand);
  animateNum($('#mbPlate'), c.perPlate);
  animateNum($('#mbTotal'), c.grand);
  animateNum($('#heroPlate'), c.perPlate);
  animateNum($('#heroTotal'), c.grand);
  $('#heroEvent').textContent = `${state.eventName || EVENTS[state.eventType].label} · ${state.guests} guests`;

  // notices
  const mn = $('#minNotice');
  const msgs = [];
  if (c.shortfall) msgs.push(`⚠️ ${v.name} has a ${v.min}-guest minimum. You are billed for ${c.billed} plates.`);
  if (c.missing.length) msgs.push(`ℹ️ Not served by this caterer: ${c.missing.map(d => d.name).join(', ')} (excluded from price).`);
  if (c.dietIssues.length) msgs.push(`🚫 ${c.dietIssues.join(' & ')} – choose another caterer for these guests.`);
  mn.hidden = !msgs.length;
  mn.innerHTML = msgs.join('<br>');

  // upsell for volume discount
  const up = $('#upsell');
  const nextTier = state.guests < 100 ? 100 : state.guests < 200 ? 200 : 0;
  if (nextTier && c.items.length) {
    const tPct = nextTier === 100 ? 5 : 10;
    up.hidden = false;
    up.innerHTML = `💡 Add <b>${nextTier - state.guests}</b> more guests to unlock a <b>${tPct}% volume discount</b>.`;
  } else if (!nextTier) {
    up.hidden = false;
    up.innerHTML = '🎉 Maximum <b>10% volume discount</b> unlocked!';
  } else up.hidden = true;

  // breakdown
  const rows = [];
  if (!c.items.length) {
    $('#breakdown').innerHTML = '<li><span>Select dishes to see your itemized quote</span><b>–</b></li>';
  } else {
    rows.push(`<li><span>Food (${c.items.length - c.missing.length} items × guests)</span><b>${fmt(c.gross)}</b></li>`);
    if (c.vp) rows.push(`<li class="neg"><span>Volume discount (${Math.round(c.vp * 100)}%)</span><b>− ${fmt(c.discount)}</b></li>`);
    if (c.jainFee) rows.push(`<li><span>Jain segregated kitchen</span><b>${fmt(c.jainFee)}</b></li>`);
    if (c.bufferAmt) rows.push(`<li><span>Leftover buffer (+${Math.round(c.bufferPct * 100)}%)</span><b>${fmt(c.bufferAmt)}</b></li>`);
    if (c.equipment) rows.push(`<li><span>Live counter equipment</span><b>${fmt(c.equipment)}</b></li>`);
    rows.push(`<li><span>Staff service fee (${SERVICE_RATE * 100}%)</span><b>${fmt(c.service)}</b></li>`);
    rows.push(`<li><span>GST (${GST_RATE * 100}%)</span><b>${fmt(c.gst)}</b></li>`);
    rows.push(`<li class="total"><span>Grand total</span><b>${fmt(c.grand)}</b></li>`);
    $('#breakdown').innerHTML = rows.join('');
  }

  // segregated segments
  const segMeta = { veg: ['Veg', '#16a34a'], nonveg: ['Non-Veg', '#dc2626'], jain: ['Jain', '#d97706'] };
  $('#segList').innerHTML = c.items.length ? Object.entries(c.segs).filter(([, s]) => s.count > 0).map(([k, s]) =>
    `<div class="seg"><span><i style="background:${segMeta[k][1]}"></i>${segMeta[k][0]} · ${s.count} guests</span><b>${fmt(s.plate)} / plate</b></div>`).join('') : '';

  // buffer
  const e = EVENTS[state.eventType];
  $('#bufferToggle').checked = state.buffer;
  $('#bufferPctLabel').textContent = '+' + Math.round(e.buffer * 100) + '%';

  // selected items grouped
  $('#selCount').textContent = `${state.selected.length} dish${state.selected.length === 1 ? '' : 'es'} selected`;
  $('#selectedItems').innerHTML = COURSES.map(co => {
    const ids = state.selected.filter(id => DISH[id].course === co.id);
    return ids.length ? `<div class="sel-group"><h6>${co.icon} ${co.label}</h6>${ids.map(id => `<span class="sel-chip">${DISH[id].name}<button type="button" data-remove="${id}" aria-label="Remove ${DISH[id].name}">✕</button></span>`).join('')}</div>` : '';
  }).join('') || '<span class="muted">Nothing yet – tap dishes in the menu builder.</span>';
}

function renderBuffer() {
  const e = EVENTS[state.eventType], v = VENDOR[state.vendorId];
  const extra = Math.ceil(state.guests * e.buffer);
  const c = calc(v, { ...state, buffer: true });
  const c0 = calc(v, { ...state, buffer: false });
  $('#bufferGrid').innerHTML = `
    <div class="bf"><b>${Math.round(e.buffer * 100)}%</b><span>Recommended cushion for ${e.label}</span></div>
    <div class="bf"><b>${state.guests}</b><span>Registered guests</span></div>
    <div class="bf"><b>+${extra}</b><span>Extra plates to prepare</span></div>
    <div class="bf"><b>${c0.items.length ? fmt(c.grand - c0.grand) : '–'}</b><span>Extra cost for buffer</span></div>
    <p class="buffer-note">📊 Based on average attendance at past ${e.label.toLowerCase()} events booked through FeastFlow. Prepare for <b>${state.guests + extra}</b> plates so nobody goes hungry – toggle it on in the quote to include the cost.</p>`;
}

/* =====================================================
   RENDER: VENDOR DIRECTORY
   ===================================================== */
function renderVendors() {
  let list = VENDORS.filter(v => ui.vendorEvent === 'all' || v.events.includes(ui.vendorEvent));
  const calcs = Object.fromEntries(list.map(v => [v.id, calc(v)]));
  const hasMenu = state.selected.length > 0;
  if (ui.vendorSort === 'rating') list.sort((a, b) => b.rating - a.rating);
  if (ui.vendorSort === 'min') list.sort((a, b) => a.min - b.min);
  if (ui.vendorSort === 'price') list.sort((a, b) => hasMenu ? calcs[a.id].grand - calcs[b.id].grand : a.tariff[0] - b.tariff[0]);

  const cheapest = hasMenu && list.length > 1
    ? list.filter(v => !calcs[v.id].dietIssues.length).reduce((m, v) => (!m || calcs[v.id].grand < calcs[m.id].grand ? v : m), null) : null;

  $('#vendorGrid').innerHTML = list.map(v => {
    const c = calcs[v.id];
    const inCmp = state.compare.includes(v.id);
    const fits = state.guests >= v.min && state.guests <= v.max;
    return `<article class="vcard ${state.vendorId === v.id ? 'chosen' : ''}">
      ${cheapest && cheapest.id === v.id ? '<span class="vbadge">💰 Best price for your menu</span>' : ''}
      <div class="vtop" style="background:${v.color}">
        <div class="vavatar">${v.emoji}</div>
        <div><h4>${v.name}</h4><small>📍 ${v.area} · ${v.exp}</small></div>
        <span class="vverified">✔ Verified</span>
      </div>
      <div class="vbody">
        <p class="muted">${v.tagline}</p>
        <div class="vstats">
          <div><b><span class="stars">★</span> ${v.rating}</b><span>${v.reviews} reviews</span></div>
          <div><b>${v.min}–${v.max}</b><span>Guest capacity</span></div>
          <div><b>${v.hygiene}/10</b><span>Hygiene score</span></div>
        </div>
        <div class="tags">
          ${v.diets.includes('veg') ? '<span class="tag good">Veg</span>' : ''}
          ${v.diets.includes('nonveg') ? '<span class="tag">Non-Veg</span>' : '<span class="tag warnt">Pure Veg</span>'}
          ${v.diets.includes('jain') ? '<span class="tag good">Jain kitchen</span>' : ''}
          ${fits ? '<span class="tag good">Fits your guest count</span>' : `<span class="tag warnt">${state.guests < v.min ? 'Min ' + v.min + ' guests' : 'Max ' + v.max + ' guests'}</span>`}
        </div>
        <div class="vprice">
          <div><small>Baseline tariff</small><span class="t">${fmt(v.tariff[0])} – ${fmt(v.tariff[1])} / plate</span></div>
          <div style="text-align:right"><small>${hasMenu ? 'Your menu' : 'Select a menu'}</small><span class="p">${hasMenu ? fmt(c.perPlate) : '–'}</span></div>
        </div>
      </div>
      <div class="vactions">
        <label class="cmp-check ${inCmp ? 'on' : ''}"><input type="checkbox" data-cmp="${v.id}" ${inCmp ? 'checked' : ''}> Add to comparison</label>
        <button class="btn btn-primary btn-sm" data-choose="${v.id}">${state.vendorId === v.id ? '✔ Selected' : 'Use for quote'}</button>
        <button class="btn btn-soft btn-sm" data-taste="${v.id}">🍴 Book Tasting</button>
        <button class="btn btn-ghost-dark btn-sm full" data-reviews="${v.id}">Read reviews (${v.reviews})</button>
      </div>
    </article>`;
  }).join('');

  renderTray();
}

function renderTray() {
  const tray = $('#compareTray');
  tray.hidden = state.compare.length === 0;
  $('#trayItems').innerHTML = `<b>Comparing (${state.compare.length}/3):</b> ` + state.compare.map(id => `<span>${VENDOR[id].emoji} ${VENDOR[id].name}</span>`).join('');
}

/* =====================================================
   RENDER: COMPARE (table on desktop, stacked cards on mobile)
   ===================================================== */
function renderCompare() {
  const out = $('#compareOut');
  if (state.compare.length < 2) {
    out.innerHTML = `<div class="cmp-empty"><div class="big-emoji">⚖️</div><h3>Pick at least two caterers</h3><p class="muted">Tick “Add to comparison” on any caterer card to see them side-by-side.</p><br><a class="btn btn-primary" href="#vendors">Browse caterers</a></div>`;
    return;
  }
  if (!state.selected.length) {
    out.innerHTML = `<div class="cmp-empty"><div class="big-emoji">🍽️</div><h3>Build a menu first</h3><p class="muted">Comparison needs a menu so every caterer can be priced for the same dishes.</p><br><a class="btn btn-primary" href="#planner">Go to Menu Builder</a></div>`;
    return;
  }
  const vs = state.compare.map(id => VENDOR[id]);
  const cs = vs.map(v => calc(v));
  const minVal = key => Math.min(...cs.map(key));
  const maxVal = key => Math.max(...cs.map(key));

  const rows = [
    { l: 'Price per plate', big: true, val: c => fmt(c.perPlate), best: c => c.perPlate === minVal(x => x.perPlate) },
    { l: `Total (${state.guests} guests)`, big: true, val: c => fmt(c.grand), best: c => c.grand === minVal(x => x.grand) },
    { l: 'Customer rating', val: c => `<span class="stars">${stars(c.vendor.rating)}</span> ${c.vendor.rating} (${c.vendor.reviews})`, best: c => c.vendor.rating === maxVal(x => x.vendor.rating) },
    { l: 'Hygiene score', val: c => `${c.vendor.hygiene} / 10`, best: c => c.vendor.hygiene === maxVal(x => x.vendor.hygiene) },
    { l: 'Baseline tariff', val: c => `${fmt(c.vendor.tariff[0])} – ${fmt(c.vendor.tariff[1])}` },
    { l: 'Minimum guests', val: c => `${c.vendor.min}${c.shortfall ? ` <span class="missing">Billed for ${c.billed}</span>` : ''}`, best: c => c.vendor.min === minVal(x => x.vendor.min) },
    { l: 'Volume discount', val: c => c.vp ? `${Math.round(c.vp * 100)}% off (${fmt(c.discount)})` : 'None at this size' },
    { l: 'Service fee + GST', val: c => fmt(c.service + c.gst) },
    { l: 'Menu inclusions', val: c => `${c.offered.length} of ${c.items.length} dishes` + (c.missing.length ? `<span class="missing">✗ ${c.missing.map(d => d.name).join(', ')}</span>` : '<span class="missing" style="color:#166534">✔ Everything on your menu</span>'), best: c => c.missing.length === 0 },
    { l: 'Dietary fit', val: c => c.dietIssues.length ? `<span class="missing">⚠ ${c.dietIssues.join(', ')}</span>` : '✔ All diets covered', best: c => c.dietIssues.length === 0 },
    { l: 'Speciality', val: c => c.vendor.tagline }
  ];

  const table = `<table class="cmp-table"><thead><tr><th>Feature</th>${vs.map(v => `<th>${v.emoji} ${v.name}</th>`).join('')}</tr></thead><tbody>
    ${rows.map(r => `<tr><th scope="row">${r.l}</th>${cs.map(c => `<td class="${r.best && r.best(c) ? 'best' : ''} ${r.big ? 'big' : ''}">${r.val(c)}</td>`).join('')}</tr>`).join('')}
    <tr class="cmp-actions"><th scope="row">Next step</th>${vs.map(v => `<td><button class="btn btn-primary btn-sm" data-taste="${v.id}">🍴 Book Tasting</button> <button class="btn btn-ghost-dark btn-sm" data-pickquote="${v.id}">Use this quote</button></td>`).join('')}</tr>
  </tbody></table>`;

  const cards = `<div class="cmp-cards">${vs.map((v, i) => { const c = cs[i]; return `<div class="cmp-card"><h4>${v.emoji} ${v.name}</h4><dl>
    ${rows.map(r => `<div><dt>${r.l}</dt><dd class="${r.best && r.best(c) ? 'best' : ''}">${r.val(c)}</dd></div>`).join('')}</dl>
    <div class="btns"><button class="btn btn-primary btn-sm" data-taste="${v.id}">🍴 Book Tasting</button><button class="btn btn-ghost-dark btn-sm" data-pickquote="${v.id}">Use this quote</button></div></div>`; }).join('')}</div>`;

  // verdict
  const byPrice = [...cs].sort((a, b) => a.grand - b.grand);
  const cheap = byPrice[0], dear = byPrice[byPrice.length - 1];
  const top = [...cs].sort((a, b) => b.vendor.rating - a.vendor.rating)[0];
  const save = dear.grand - cheap.grand;
  const verdict = `<div class="verdict">🏆 <b>${esc(cheap.vendor.name)}</b> is the most affordable at <b>${fmt(cheap.perPlate)}/plate</b>, saving <b>${fmt(save)}</b> over ${esc(dear.vendor.name)}.
    ${top.vendor.id !== cheap.vendor.id ? ` For the best reputation, <b>${esc(top.vendor.name)}</b> leads with ${top.vendor.rating}★ — a trade-off of ${fmt(top.grand - cheap.grand)} more.` : ' It is also the highest rated of the group.'}
    Book a tasting before you decide.</div>`;

  out.innerHTML = table + cards + verdict;
}

/* =====================================================
   RENDER: ESCROW SIMULATOR
   ===================================================== */
const MILES = [
  { pct: 0.2, label: 'Advance', when: 'On booking' },
  { pct: 0.5, label: 'Event Day', when: 'On the day of the event' },
  { pct: 0.3, label: 'Post-Event Settlement', when: '7 days after the event' }
];
const ESC_BTN = ['Pay 20% advance into escrow', 'Event day – pay 50% into escrow', 'Event delivered – pay 30% settlement', 'Approve & release final payment', 'Simulation complete ✔'];
const ESC_LOG = [
  'Advance (20%) deposited – held safely in escrow.',
  'Event-day payment (50%) deposited – advance released to the caterer.',
  'Event confirmed delivered – event-day payment released, 30% held for settlement.',
  'Host approved settlement – final payment released. Deal closed!'
];
function renderEscrow() {
  const v = VENDOR[state.vendorId], c = calc(v);
  const date = state.eventDate ? new Date(state.eventDate + 'T00:00:00') : addDays(new Date(), 14);
  const dates = [new Date(), date, addDays(date, 7)].map(d => d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }));
  const st = state.escrow;
  $('#escVendor').textContent = v.name;
  $('#escTotal').textContent = c.grand ? fmt(c.grand) : 'Build a menu to start';
  $('#escGrid').innerHTML = MILES.map((m, i) => {
    // stage mapping: M(i) pending if st<=i, held if st==i+1, released if st>=i+2
    const status = st <= i ? 'pending' : st === i + 1 ? 'held' : 'released';
    const label = { pending: 'Pending', held: '🔒 Held in escrow', released: '✔ Released to vendor' }[status];
    return `<div class="mile ${status}"><div class="pct">${m.pct * 100}%</div><div class="amt">${fmt(c.grand * m.pct)}</div><div class="when"><b>${m.label}</b><br>${m.when} · ${dates[i]}</div><span class="status ${status}">${label}</span></div>`;
  }).join('');
  $('#escFill').style.width = (st / 4 * 100) + '%';
  const btn = $('#escNext');
  btn.textContent = ESC_BTN[st];
  btn.disabled = st >= 4 || !c.grand;
  btn.style.opacity = btn.disabled ? .6 : 1;
  $('#escLog').innerHTML = ESC_LOG.slice(0, st).map(t => `<li>${t}</li>`).join('');
}

/* =====================================================
   RENDER: TASTING
   ===================================================== */
function renderTastings() {
  const box = $('#tastingList');
  if (!tastings.length) { box.innerHTML = '<div class="t-empty">No tasting requests yet.<br>Choose a caterer and book your first session 🍴</div>'; return; }
  box.innerHTML = tastings.map(t => `<div class="t-item"><span class="ico">🥘</span><div class="info"><b>${esc(t.vendorName)}</b><span>${pretty(t.date)} · ${esc(t.time)} · ${esc(t.venue)}<br>${esc(t.name)} · ${t.people} people · Code <b>${t.code}</b></span></div><div style="text-align:right"><span class="status held">⏳ Awaiting confirmation</span><br><br><button class="x-btn" data-cancel="${t.code}">Cancel</button></div></div>`).join('');
}
function saveTastings() { try { localStorage.setItem('feastflow.tastings', JSON.stringify(tastings)); } catch (e) { /* ignore */ } }

function openTasting(vendorId) {
  const sel = $('#tVendor');
  sel.innerHTML = VENDORS.map(v => `<option value="${v.id}">${v.emoji} ${v.name}</option>`).join('');
  sel.value = vendorId || state.vendorId;
  const min = localISO(addDays(new Date(), 1));
  $('#tDate').min = min;
  if (!$('#tDate').value || $('#tDate').value < min) $('#tDate').value = localISO(addDays(new Date(), 3));
  $$('#tastingForm .err').forEach(e => (e.textContent = ''));
  $$('#tastingForm .bad').forEach(e => e.classList.remove('bad'));
  $('#tAddressWrap').hidden = $('#tVenueType').value !== 'my';
  openModal('#tastingModal');
  setTimeout(() => $('#tName').focus(), 50);
}

function submitTasting(e) {
  e.preventDefault();
  let ok = true;
  const setErr = (id, msg) => { const el = $('#' + id); const er = $(`.err[data-for="${id}"]`); if (er) er.textContent = msg || ''; el.classList.toggle('bad', !!msg); if (msg) ok = false; };
  const name = $('#tName').value.trim(), phone = $('#tPhone').value.trim(), date = $('#tDate').value;
  const type = $('#tVenueType').value, addr = $('#tAddress').value.trim();
  setErr('tName', name.length < 2 ? 'Please enter your name' : '');
  setErr('tPhone', /^[6-9]\d{9}$/.test(phone) ? '' : 'Enter a valid 10-digit mobile number');
  setErr('tDate', !date || date < localISO(addDays(new Date(), 1)) ? 'Pick a date from tomorrow onwards' : '');
  setErr('tAddress', type === 'my' && addr.length < 4 ? 'Please enter the venue address' : '');
  if (!ok) return;
  const v = VENDOR[$('#tVendor').value];
  const code = 'TS-' + Math.random().toString(36).slice(2, 6).toUpperCase();
  tastings.unshift({
    code, vendorId: v.id, vendorName: v.name, name, phone, date, time: $('#tTime').value,
    venue: type === 'my' ? addr : `${v.name} tasting studio, ${v.area}`, people: clamp(parseInt($('#tPeople').value) || 1, 1, 12)
  });
  saveTastings(); renderTastings();
  closeModals();
  toast(`✅ Tasting requested with ${v.name}! Code ${code}`);
  setTimeout(() => $('#tasting').scrollIntoView({ behavior: 'smooth' }), 400);
}

/* =====================================================
   RENDER: GALLERY + REVIEWS
   ===================================================== */
function renderGallery() {
  const list = GALLERY.filter(g => ui.gallery === 'all' || g.e === ui.gallery);
  $('#galleryGrid').innerHTML = list.map(g => `<article class="gcard">
    <div class="gimg" style="background:${g.bg}"><span class="ver">✔ Verified event</span><span>${g.ic}</span><span class="cnt">👥 ${g.g} guests</span></div>
    <div class="gbody"><h4>${g.t}</h4><div class="gmeta">${EVENTS[g.e].icon} ${EVENTS[g.e].label} · catered by ${VENDOR[g.v].name}</div>
    <blockquote>“${g.q}”</blockquote><div class="gfoot"><span class="stars">★★★★★</span><span>— ${g.by}</span></div></div></article>`).join('');
}
function openReviews(id) {
  const v = VENDOR[id];
  $('#rmTitle').textContent = `${v.emoji} ${v.name} – Reviews`;
  $('#reviewsBody').innerHTML = `<p class="muted"><span class="stars">${stars(v.rating)}</span> ${v.rating} from ${v.reviews} verified hosts · Hygiene ${v.hygiene}/10</p>` +
    v.testimonials.map(t => `<div class="rev"><b>${esc(t[0])} <span class="stars">${stars(t[2])}</span></b>${esc(t[1])}</div>`).join('');
  openModal('#reviewsModal');
}

/* =====================================================
   QUOTATION PDF
   ===================================================== */
function openQuote() {
  if (!state.selected.length) { toast('Please select at least one dish first 🍽️'); $('#planner').scrollIntoView({ behavior: 'smooth' }); return; }
  const v = VENDOR[state.vendorId], c = calc(v);
  if (!c.offered.length) { toast('This caterer offers none of the selected dishes. Try another caterer.'); return; }
  const qno = 'FF-' + localISO(new Date()).replace(/-/g, '') + '-' + (Math.abs(hash(state.selected.join() + v.id + state.guests)) % 9000 + 1000);
  const vseg = { veg: 'Vegetarian', nonveg: 'Non-Vegetarian', jain: 'Jain' };

  let body = '';
  COURSES.forEach(co => {
    const ls = c.lines.filter(l => l.dish.course === co.id);
    if (!ls.length) return;
    body += `<tr class="course"><td colspan="5">${co.icon} ${co.label}</td></tr>` +
      ls.map(l => `<tr><td>${l.dish.name}</td><td>${l.dish.diet === 'nonveg' ? 'Non-veg' : l.dish.diet === 'jain' ? 'Jain' : 'Veg'}</td><td class="r">${fmt(l.unit)}</td><td class="r">${Math.round(l.qty)}</td><td class="r">${fmt(l.amount)}</td></tr>`).join('');
  });

  const eq = c.offered.filter(d => d.equip);
  const totals = [
    ['Food subtotal (before discount)', fmt(c.gross)],
    c.vp ? [`Volume discount (${Math.round(c.vp * 100)}%)`, '− ' + fmt(c.discount)] : null,
    c.jainFee ? ['Jain segregated kitchen surcharge', fmt(c.jainFee)] : null,
    c.bufferAmt ? [`Leftover buffer (+${Math.round(c.bufferPct * 100)}%)`, fmt(c.bufferAmt)] : null,
    c.equipment ? [`Live counter equipment (${eq.map(d => d.name).join(', ')})`, fmt(c.equipment)] : null,
    [`Staff service fee (${SERVICE_RATE * 100}%)`, fmt(c.service)],
    [`GST (${GST_RATE * 100}%)`, fmt(c.gst)]
  ].filter(Boolean);

  $('#quoteDoc').innerHTML = `
    <div class="qh"><div><div class="brand">Feast<span>Flow</span></div><div>EventEats Exchange · Catering Quotation</div></div>
      <div class="meta"><b>${qno}</b><br>Date: ${pretty(localISO(new Date()))}<br>Valid until: ${pretty(localISO(addDays(new Date(), 7)))}</div></div>
    <div class="q2">
      <div class="qbox"><h6>Event details</h6><b>${esc(state.eventName || EVENTS[state.eventType].label + ' Event')}</b><br>Type: ${EVENTS[state.eventType].label}<br>Date: ${pretty(state.eventDate)}<br>
        Guests: ${state.guests} (${Object.entries(c.segs).filter(([, s]) => s.count).map(([k, s]) => `${s.count} ${vseg[k]}`).join(', ')})</div>
      <div class="qbox"><h6>Caterer</h6><b>${v.name}</b><br>${v.area} · ${v.exp} experience<br>Rating ${v.rating}★ · Hygiene ${v.hygiene}/10<br>${c.shortfall ? `Minimum billing: ${c.billed} plates` : `Billed plates: ${c.billed}`}</div>
    </div>
    <table class="qtable"><thead><tr><th>Item</th><th>Diet</th><th class="r">Rate/plate</th><th class="r">Plates</th><th class="r">Amount</th></tr></thead><tbody>${body}</tbody></table>
    <div class="qtotals">
      ${totals.map(t => `<div><span>${t[0]}</span><b>${t[1]}</b></div>`).join('')}
      <div class="grand"><span>GRAND TOTAL</span><span>${fmt(c.grand)}</span></div>
      <div><span>Effective cost per plate</span><b>${fmt(c.perPlate)}</b></div>
    </div>
    ${c.missing.length ? `<p class="qterms"><b>Note:</b> Not offered by this caterer and excluded: ${c.missing.map(d => d.name).join(', ')}.</p>` : ''}
    <div class="qpay"><div>Advance (20%)<b>${fmt(c.grand * .2)}</b>On booking</div><div>Event day (50%)<b>${fmt(c.grand * .5)}</b>${pretty(state.eventDate)}</div><div>Settlement (30%)<b>${fmt(c.grand * .3)}</b>7 days post-event</div></div>
    <ul class="qterms"><li>Prices are per-plate with volume-tier discounts applied automatically (5% for 100–199 guests, 10% for 200+).</li>
      <li>Final headcount to be confirmed 72 hours before the event. This is an indicative quote; a tasting session is recommended before contract signing.</li>
      <li>Payments are held in FeastFlow escrow and released milestone-by-milestone on host confirmation.</li></ul>
    <div class="qsign"><div>Prepared by (Organizer)</div><div>Treasurer / Committee Head</div><div>Faculty Coordinator / Approver</div></div>`;
  openModal('#quoteModal');
  saveQuotation(qno, v, c);
}
function hash(s) { let h = 0; for (let i = 0; i < s.length; i++) h = (h << 5) - h + s.charCodeAt(i) | 0; return h; }
function saveQuotation(no, v, c) {
  try {
    const arr = JSON.parse(localStorage.getItem('feastflow.quotations') || '[]');
    if (!arr.find(q => q.no === no)) arr.unshift({ no, vendor: v.name, total: Math.round(c.grand), guests: state.guests, at: new Date().toISOString() });
    localStorage.setItem('feastflow.quotations', JSON.stringify(arr.slice(0, 20)));
  } catch (e) { /* ignore */ }
}
function printQuote() {
  document.body.classList.add('print-quote');
  const done = () => { document.body.classList.remove('print-quote'); window.removeEventListener('afterprint', done); };
  window.addEventListener('afterprint', done);
  window.print();
  setTimeout(done, 1500);
}

/* =====================================================
   DEMOS
   ===================================================== */
function loadFarewell() {
  Object.assign(state, {
    eventType: 'college', eventName: 'CSE Farewell Dinner', eventDate: localISO(addDays(new Date(), 21)),
    guests: 150, nonveg: 30, jain: 10, vendorId: 'royal', buffer: true, compare: ['royal', 'spice'], escrow: 0,
    selected: ['s2', 's4', 's5', 'm3', 'm2', 'm4', 'm7', 'b1', 'd1', 'd3', 'c1']
  });
  fullRender();
  toast('🎓 Loaded: 150-person college farewell dinner. Scroll to compare caterers!');
  setTimeout(() => $('#planner').scrollIntoView({ behavior: 'smooth' }), 150);
}
function loadBanquet() {
  Object.assign(state, {
    eventType: 'corporate', eventName: 'Department Banquet', eventDate: localISO(addDays(new Date(), 14)),
    guests: 100, nonveg: 0, jain: 0, vendorId: 'royal', buffer: false, compare: ['royal', 'spice'], escrow: 0,
    selected: ['s1', 's2', 'm1', 'm2', 'm3', 'd1', 'd2']
  });
  fullRender();
  toast('🍽️ Loaded: 100-person Department Banquet');
  setTimeout(() => $('#planner').scrollIntoView({ behavior: 'smooth' }), 150);
}

/* =====================================================
   MASTER RENDER + EVENTS
   ===================================================== */
function update() {
  renderTabs(); renderDishes(); renderSummary(); renderBuffer(); renderVendors(); renderCompare(); renderEscrow();
  save();
}
function fullRender() {
  $('#eventName').value = state.eventName;
  $('#eventDate').value = state.eventDate;
  renderEventChips(); syncGuestInputs(); update();
}

function bind() {
  // Event type
  $('#eventChips').addEventListener('click', e => {
    const b = e.target.closest('[data-ev]'); if (!b) return;
    state.eventType = b.dataset.ev;
    renderEventChips(); update();
  });
  $('#eventName').addEventListener('input', e => { state.eventName = e.target.value; renderSummary(); save(); });
  $('#eventDate').min = localISO(new Date());
  $('#eventDate').addEventListener('change', e => { state.eventDate = e.target.value; renderEscrow(); save(); });

  // Guests
  const setGuests = n => { state.guests = clamp(parseInt(n) || MIN_G, MIN_G, MAX_G); fixDiet(); syncGuestInputs(); update(); };
  $('#guestSlider').addEventListener('input', e => setGuests(e.target.value));
  $('#guestNumber').addEventListener('change', e => setGuests(e.target.value));
  $('#nonvegCount').addEventListener('input', e => { state.nonveg = clamp(parseInt(e.target.value) || 0, 0, state.guests - state.jain); syncGuestInputs(); update(); });
  $('#jainCount').addEventListener('input', e => { state.jain = clamp(parseInt(e.target.value) || 0, 0, state.guests - state.nonveg); syncGuestInputs(); update(); });
  $('#dietPresets').addEventListener('click', e => {
    const b = e.target.closest('[data-preset]'); if (!b) return;
    const g = state.guests;
    if (b.dataset.preset === 'veg') { state.nonveg = 0; state.jain = 0; }
    if (b.dataset.preset === 'mixed') { state.nonveg = Math.round(g * .4); state.jain = 0; }
    if (b.dataset.preset === 'jain') { state.nonveg = 0; state.jain = Math.round(g * .2); }
    syncGuestInputs(); update();
  });

  // Menu
  $('#courseTabs').addEventListener('click', e => { const b = e.target.closest('[data-tab]'); if (!b) return; ui.tab = b.dataset.tab; renderTabs(); renderDishes(); });
  $('#dishGrid').addEventListener('click', e => { const b = e.target.closest('[data-dish]'); if (b) toggleDish(b.dataset.dish); });
  $('#dietFilter').addEventListener('click', e => {
    const b = e.target.closest('[data-f]'); if (!b) return;
    ui.filter = b.dataset.f; $$('#dietFilter .chip').forEach(c => c.classList.toggle('active', c === b)); renderDishes();
  });
  $('#dishSearch').addEventListener('input', e => { ui.query = e.target.value; renderDishes(); });
  $('#applyPackage').addEventListener('click', applyPackage);
  $('#clearMenu').addEventListener('click', () => { state.selected = []; update(); toast('Menu cleared'); });

  // Summary
  $('#vendorSelect').addEventListener('change', e => { state.vendorId = e.target.value; update(); });
  $('#bufferToggle').addEventListener('change', e => { state.buffer = e.target.checked; update(); });
  $('#selectedItems').addEventListener('click', e => { const b = e.target.closest('[data-remove]'); if (b) toggleDish(b.dataset.remove); });
  $('#bookSelected').addEventListener('click', () => openTasting(state.vendorId));
  $$('[data-open-quote]').forEach(b => b.addEventListener('click', openQuote));

  // Vendors
  $('#vendorFilter').addEventListener('click', e => {
    const b = e.target.closest('[data-e]'); if (!b) return;
    ui.vendorEvent = b.dataset.e; $$('#vendorFilter .chip').forEach(c => c.classList.toggle('active', c === b)); renderVendors();
  });
  $('#vendorSort').addEventListener('change', e => { ui.vendorSort = e.target.value; renderVendors(); });
  $('#vendorGrid').addEventListener('click', e => {
    const ch = e.target.closest('[data-choose]'), ta = e.target.closest('[data-taste]'), rv = e.target.closest('[data-reviews]');
    if (ch) { state.vendorId = ch.dataset.choose; update(); toast(`Quote now uses ${VENDOR[state.vendorId].name}`); }
    if (ta) openTasting(ta.dataset.taste);
    if (rv) openReviews(rv.dataset.reviews);
  });
  $('#vendorGrid').addEventListener('change', e => {
    const cb = e.target.closest('[data-cmp]'); if (!cb) return;
    const id = cb.dataset.cmp;
    if (cb.checked) {
      if (state.compare.length >= 3) { cb.checked = false; toast('You can compare up to 3 caterers'); return; }
      state.compare.push(id);
    } else state.compare = state.compare.filter(x => x !== id);
    renderVendors(); renderCompare(); save();
  });

  // Compare actions
  $('#compareOut').addEventListener('click', e => {
    const ta = e.target.closest('[data-taste]'), pq = e.target.closest('[data-pickquote]');
    if (ta) openTasting(ta.dataset.taste);
    if (pq) { state.vendorId = pq.dataset.pickquote; update(); toast(`Quote updated for ${VENDOR[state.vendorId].name}`); $('#summary').scrollIntoView({ behavior: 'smooth', block: 'center' }); }
  });

  // Escrow
  $('#escNext').addEventListener('click', () => { if (state.escrow < 4) { state.escrow++; renderEscrow(); save(); } });
  $('#escReset').addEventListener('click', () => { state.escrow = 0; renderEscrow(); save(); });

  // Tasting
  $('#openTastingMain').addEventListener('click', () => openTasting(state.vendorId));
  $('#tastingForm').addEventListener('submit', submitTasting);
  $('#tVenueType').addEventListener('change', e => { $('#tAddressWrap').hidden = e.target.value !== 'my'; });
  $('#tPhone').addEventListener('input', e => { e.target.value = e.target.value.replace(/\D/g, ''); });
  $('#tastingList').addEventListener('click', e => {
    const b = e.target.closest('[data-cancel]'); if (!b) return;
    tastings = tastings.filter(t => t.code !== b.dataset.cancel); saveTastings(); renderTastings(); toast('Tasting request cancelled');
  });

  // Gallery
  $('#galleryFilter').addEventListener('click', e => {
    const b = e.target.closest('[data-g]'); if (!b) return;
    ui.gallery = b.dataset.g; $$('#galleryFilter .chip').forEach(c => c.classList.toggle('active', c === b)); renderGallery();
  });

  // Quote
  $('#printQuote').addEventListener('click', printQuote);

  // Modals
  $$('.modal').forEach(m => m.addEventListener('click', e => { if (e.target === m || e.target.closest('[data-close]')) closeModals(); }));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModals(); });

  // Demos
  $('#demoFarewell').addEventListener('click', loadFarewell);
  $('#demoBanquet').addEventListener('click', loadBanquet);

  // Nav
  const nav = $('#nav'), links = $('#navLinks'), burger = $('#burger');
  const onScroll = () => nav.classList.toggle('scrolled', window.scrollY > 40);
  window.addEventListener('scroll', onScroll, { passive: true }); onScroll();
  burger.addEventListener('click', () => { const o = links.classList.toggle('open'); burger.setAttribute('aria-expanded', o); burger.textContent = o ? '✕' : '☰'; });
  links.addEventListener('click', e => { if (e.target.tagName === 'A') { links.classList.remove('open'); burger.textContent = '☰'; } });

  // Active link highlight
  const secs = ['planner', 'vendors', 'compare', 'payments', 'tasting', 'gallery'].map(id => document.getElementById(id));
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver(es => es.forEach(en => {
      if (en.isIntersecting) $$('.nav-links a').forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#' + en.target.id));
    }), { rootMargin: '-45% 0px -50% 0px' });
    secs.forEach(s => s && io.observe(s));
  }
}

/* Scroll reveal + hero counters */
function initReveal() {
  const els = $$('.reveal');
  if (!('IntersectionObserver' in window)) { els.forEach(e => e.classList.add('in')); return; }
  const io = new IntersectionObserver(es => es.forEach(en => { if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); } }), { threshold: .08 });
  els.forEach(e => io.observe(e));
  // safety: never leave content hidden
  setTimeout(() => els.forEach(e => e.classList.add('in')), 2500);
}
function initCounters() {
  $$('[data-count]').forEach(el => {
    const to = +el.dataset.count; let n = 0;
    if (to === 0) { el.textContent = '0'; return; }
    const t = setInterval(() => { n += Math.ceil(to / 20); if (n >= to) { n = to; clearInterval(t); } el.textContent = n; }, 50);
  });
}

/* ---------- Boot ---------- */
document.addEventListener('DOMContentLoaded', () => {
  load();
  if (!state.selected.length && !localStorage.getItem(KEY)) {
    state.selected = EVENTS[state.eventType].pkg.slice();   // first visit: show a ready-made menu
  }
  bind();
  fullRender();
  renderTastings();
  renderGallery();
  initReveal();
  initCounters();
});